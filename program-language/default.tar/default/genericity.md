---
layout: page
permalink: /program-language/default/genericity
---

Genericity
