---
layout: page
permalink: /program-language/default/effective
---

Effective

