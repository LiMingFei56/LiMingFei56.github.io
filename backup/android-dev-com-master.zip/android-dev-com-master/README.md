android-dev-com  
==========  
Some Famous Android Developers Information,  Welcome to [commit](https://github.com/android-cn/android-dev-com/wiki "Standard of adding and editing content").  

网页版：[国外著名 Android 开发者及公司信息 ](http://codekk.com/blogs/detail/codeKK/%E5%9B%BD%E5%A4%96%E8%91%97%E5%90%8D%20Android%20%E5%BC%80%E5%8F%91%E8%80%85%E5%8F%8A%E5%85%AC%E5%8F%B8%E4%BF%A1%E6%81%AF)  
>[中国部分 Android 开发者](https://github.com/android-cn/android-dev-cn)  
>分享：<a href="http://service.weibo.com/share/share.php?url=https%3A%2F%2Fgithub.com%2Fandroid-cn%2Fandroid-dev-com&title=%E5%9B%BD%E5%A4%96%E8%91%97%E5%90%8D+Android+%E5%BC%80%E5%8F%91%E8%80%85+Github+%E5%92%8C%E5%8D%9A%E5%AE%A2%E5%9C%B0%E5%9D%80%EF%BC%8C%E6%AC%A2%E8%BF%8E%E8%A1%A5%E5%85%85%E5%92%8C%E6%8E%A8%E8%8D%90+%40Trinea+&appkey=1657413438&searchPic=true" target="_blank" title="分享到新浪微博" style="width:100%"><img src="http://farm8.staticflickr.com/7342/13103239365_e5cd37fbac_o.png" title="分享到新浪微博"/></a>  

Avatar  | Github | Blog | Description
-------------: | :------------- | :------------- | :------------- 
![Google Android](https://avatars3.githubusercontent.com/u/1342004?s=80 "Google Android") | https://github.com/google | http://android-developers.blogspot.com/ |  Google Android Developers Blog
![JakeWharton](https://avatars0.githubusercontent.com/u/66577?s=80 "JakeWharton") | https://github.com/JakeWharton | http://jakewharton.com/ |  ActionBarSherlock, Android-ViewPagerIndicator, Nine Old Androids, butterknife
![Square](https://avatars0.githubusercontent.com/u/82592?s=80 "Square") | https://github.com/square   | http://square.github.io/ | okhttp, fest-android, android-times-square, picasso, dagger, spoon
![Chris Banes](https://avatars3.githubusercontent.com/u/227486?s=80 "Chris Banes")  | https://github.com/chrisbanes | http://chris.banes.me/ | ActionBar-PullToRefresh, PhotoView, Android-BitmapCache, Android-PullToRefresh
![Jeremy Feinstein](https://avatars0.githubusercontent.com/u/1269143?s=80 "Jeremy Feinstein") | https://github.com/jfeinstein10 | http://jeremyfeinstein.com/ | SlidingMenu, JazzyViewPager
![Sergey Tarasevich](https://avatars3.githubusercontent.com/u/1223348?s=80 "Sergey Tarasevich") | https://github.com/nostra13 | http://nostra13android.blogspot.com/ | Android-Universal-Image-Loader
![Koushik Dutta](https://avatars3.githubusercontent.com/u/73924?s=80 "Koushik Dutta") | https://github.com/koush   | http://koush.com/  | Superuser, AndroidAsync, UrlImageViewHelper  
![Simon Vig](https://avatars2.githubusercontent.com/u/549365?s=80 "Simon Vig") | https://github.com/SimonVT |  http://simonvt.net/ | android-menudrawer, MessageBar 
![Cyril Mottier](https://avatars1.githubusercontent.com/u/92794?s=80 "Cyril Mottier") | https://github.com/cyrilmottier |  http://cyrilmottier.com/ | GreenDroid, Polaris
![Emil Sjolander](https://avatars2.githubusercontent.com/u/1525924?s=80 "Emil Sjolander") | https://github.com/emilsjolander |  http://emilsjolander.se/ | StickyListHeaders, sprinkles, android-FlipView
![James Smith](https://avatars1.githubusercontent.com/u/104009?s=80 "James Smith") | https://github.com/loopj | http://loopj.com | android-async-http
![Manuel Peinado](https://avatars2.githubusercontent.com/u/2700015?s=80 "Manuel Peinado") |  https://github.com/ManuelPeinado  |   | FadingActionBar, GlassActionBar, RefreshActionItem, QuickReturnHeader
![greenrobot](https://avatars2.githubusercontent.com/u/242242?s=80 "greenrobot") | https://github.com/greenrobot | http://greenrobot.de/  | greenDAO, EventBus
![Jeff Gilfelt](https://avatars0.githubusercontent.com/u/175697?s=80 "Jeff Gilfelt") |  https://github.com/jgilfelt  |  http://jeffgilfelt.com  |  android-mapviewballoons, android-viewbadger, android-actionbarstylegenerator, android-sqlite-asset-helper
![Roman Nurik](https://avatars0.githubusercontent.com/u/100155?s=80 "Roman Nurik") | https://github.com/romannurik | http://roman.nurik.net/ | muzei, Android-SwipeToDismiss
![Flavien Laurent](https://avatars1.githubusercontent.com/u/4429434?s=80 "Flavien Laurent") | https://github.com/flavienlaurent | http://www.flavienlaurent.com | NotBoringActionBar, datetimepicker, discrollview
![Gabriele Mariotti](https://avatars0.githubusercontent.com/u/2583078?s=80 "Gabriele Mariotti") | https://github.com/gabrielemariotti | http://gmariotti.blogspot.it | cardslib, colorpickercollection
![sephiroth74](https://avatars0.githubusercontent.com/u/823858?s=80 "sephiroth74") | https://github.com/sephiroth74 |  http://www.sephiroth.it/ | ImageViewZoom, HorizontalVariableListView, AndroidWheel, purePDF
![Romain Guy](https://avatars0.githubusercontent.com/u/869684?s=80 "Romain Guy") | https://github.com/romainguy |  http://www.curious-creature.org   |  ViewServer
![Kevin Sawicki](https://avatars1.githubusercontent.com/u/671378?s=80 "Kevin Sawicki") | https://github.com/kevinsawicki | https://twitter.com/kevinsawicki | http-request
![Christopher Jenkins](https://avatars0.githubusercontent.com/u/1167793?s=80 "Christopher Jenkins") | https://github.com/chrisjenx | http://about.me/chris.jenkins | Calligraphy, ParallaxScrollView
![Javier Pardo](https://avatars0.githubusercontent.com/u/1172221?s=80 "Javier Pardo") |  https://github.com/jpardogo | http://jpardogo.com | ListBuddies, FlabbyListView, GoogleProgressBar, FadingActionBar
![Chet Haase](https://lh4.googleusercontent.com/-alRF2kfXilM/AAAAAAAAAAI/AAAAAAAAH4U/1yMUbANZ_YY/s80-c/photo.jpg "Chet Haase")  |    |  http://graphics-geek.blogspot.com/ | Android framework UI team
![Matthias Käppler](https://avatars2.githubusercontent.com/u/102802?s=80 "Matthias Käppler") | https://github.com/mttkay | http://mttkay.github.io/ | signpost
![Daniel Lew](https://avatars3.githubusercontent.com/u/514850?s=80 "Daniel Lew") | https://github.com/dlew | http://blog.danlew.net/ | Android Tips
![FaceBook](https://avatars0.githubusercontent.com/u/69631?v=3&s=80 "FaceBook") | https://github.com/facebook | https://code.facebook.com/mobile/ | buck
Code Zen | | http://arpitonline.com/ | iOS Android
![Styling Android](https://lh3.googleusercontent.com/-8MrsyY2gqwM/AAAAAAAAAAI/AAAAAAAAAC4/fhUUNvYEqqo/s80-c-k-no/photo.jpg) | [Google Plus](https://plus.google.com/101161883485148457960?prsrc=3) | https://blog.stylingandroid.com/ | A techical guide to to improving the UI and UX Android apps
