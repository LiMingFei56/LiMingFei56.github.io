android-dev-cn
==========
一些国内 Android 开发者信息，欢迎提交修改  
>[国外部分开发者信息](https://github.com/android-cn/android-dev-com)  
>分享：<a href="http://service.weibo.com/share/share.php?url=https%3A%2F%2Fgithub.com%2Fandroid-cn%2Fandroid-dev-cn&title=%E5%9B%BD%E5%86%85%E8%91%97%E5%90%8D+Android+%E5%BC%80%E5%8F%91%E8%80%85+Github+%E5%92%8C%E5%8D%9A%E5%AE%A2%E5%9C%B0%E5%9D%80%EF%BC%8C%E6%AC%A2%E8%BF%8E%E8%A1%A5%E5%85%85%E5%92%8C%E6%8E%A8%E8%8D%90+%40Trinea+&appkey=1657413438&searchPic=true" target="_blank" title="分享到新浪微博" style="width:100%"><img src="http://farm8.staticflickr.com/7342/13103239365_e5cd37fbac_o.png" title="分享到新浪微博"/></a>  

昵称 | GitHub | 博客 | 介绍
:------------- | :------------- | :------------- | :-------------
罗升阳 | | [Luoshengyang@csdn](http://blog.csdn.net/Luoshengyang) | Android 源码分析
邓凡平 | | [innost@csdn](http://blog.csdn.net/innost) | 阿拉神农
魏祝林 | | [android_tutor@csdn](http://blog.csdn.net/android_tutor) |
Trinea | [trinea ](https://github.com/trinea) | [trinea.cn](http://www.trinea.cn/) | 性能优化 开源项目
halzhang | [halzhang ](https://github.com/halzhang) | [halzhang@cnblogs](http://www.cnblogs.com/halzhang) | StartNews作者
wyouflf | [wyouflf ](https://github.com/wyouflf) | [wyouflf@oschina](http://my.oschina.net/u/1171837) | xUtils作者
张兴业 | | [xyz_lmn@csdn](http://blog.csdn.net/xyz_lmn) |
代码家 | [daimajia ](https://github.com/daimajia) | [daimajia.com](http://blog.daimajia.com/) |
stormzhang | [stormzhang ](https://github.com/stormzhang) | [stormzhang](http://stormzhang.github.io/) | 9Gag作者 AndroidDesign Love开源
郭霖 | | [guolin_blog@csdn](http://blog.csdn.net/guolin_blog) |
hanyonglu | | [hanyonglu@cnblogs](http://www.cnblogs.com/hanyonglu) | Android动画与推送
闷瓜蛋子 | | [fookwood.com](http://www.fookwood.com)  | 云OS开发
傲慢的上校 | | [lilu_leo@csdn](http://blog.csdn.net/lilu_leo) |  
youxiachai | [youxiachai ](https://github.com/youxiachai) | |
dodola | [dodola ](https://github.com/dodola) | |
Issacw0ng | [Issacw0ng ](https://github.com/Issacw0ng) | [imid.me](http://imid.me) |
mcxiaoke | [mcxiaoke ](https://github.com/mcxiaoke) | |
soarcn | [soarcn ](https://github.com/soarcn) | |
谦虚的天下 | | [qianxudetianxia@cnblogs](http://www.cnblogs.com/qianxudetianxia) |
李华明Himi | | [xiaominghimi@csdn](http://blog.csdn.net/xiaominghimi) |
yangfuhai | [yangfuhai ](https://github.com/yangfuhai) | | afinal 作者
张国威 | | [hellogv@csdn](http://blog.csdn.net/hellogv) |  
程序媛念茜 | | [yiyaaixuexi@csdn](http://blog.csdn.net/yiyaaixuexi) |  
wangjinyu501 | | [wangjinyu501@csdn](http://blog.csdn.net/wangjinyu501) |  
ASCE1885 | | [asce1885@csdn](http://blog.csdn.net/asce1885) |
qinjuning | | [qinjuning@csdn](http://blog.csdn.net/qinjuning) |   
秋风的博客 | | [tangcheng_ok@csdn](http://blog.csdn.net/tangcheng_ok) |
任玉刚 | [singwhatiwanna ](https://github.com/singwhatiwanna) | [singwhatiwanna@csdn](http://blog.csdn.net/singwhatiwanna) |
农民伯伯 | [over140 ](https://github.com/over140) | [over140](http://over140.cnblogs.com) | [开源播放器](https://github.com/over140/OPlayer) Android 中文 api
李宏伟 | [lihw ](https://github.com/lihw) | [paper3d.net](http://www.paper3d.net) | [Paper3D](https://github.com/lihw/FutureInterface)
代震军 | [daizhenjun ](https://github.com/daizhenjun) | [daizhj@cnblogs](http://www.cnblogs.com/daizhj) | [ImageFilter库](https://github.com/daizhenjun/ImageFilterForAndroid)
sunzn | | [sunzn@cnblogs](http://www.cnblogs.com/sunzn) | Android 基础开发知识
pedant | [pedant ](https://github.com/pedant) | [书呆子精神院](http://pedant.cn/) | [SweetAlertDialog](https://github.com/pedant/sweet-alert-dialog)、安全与逆向
androidyue | [androidyue](https://github.com/androidyue) | [技术小黑屋](http://droidyue.com/) | Android，Java研究
Hongyang | [hongyangAndroid](https://github.com/hongyangAndroid)| [Hongyang](http://blog.csdn.net/lmj623565791)| Android
大头鬼 | [Bruce Lee](https://github.com/lzyzsd)| [大头鬼Bruce](http://blog.csdn.net/lzyzsd/)| Android, RxJava
markzhai | [markzhai](https://github.com/markzhai)| [markzhai的博客](http://blog.zhaiyifan.cn/)| Android
